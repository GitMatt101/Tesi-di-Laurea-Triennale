#pragma once
#include <vector>
#include <glm/mat4x4.hpp>
#include <GL/glew.h>
#include "vertex.hpp"
using namespace glm;
using namespace std;

/**
* Class that models a generic shape.
*/
class Shape {
	private:
		GLuint shapeVAO;
		GLuint verticesVBO;
		GLuint colorsVBO;
		mat4 model;
		vector<Vertex> vertices;
		float x;
		float y;
		float rotationAngle;

	public:
		Shape(vector<Vertex> vertices);
		void initVAO();
		GLuint* getVAO();
		GLuint* getVerticesVBO();
		GLuint* getColorsVBO();
		vector<Vertex> getVertices();
		mat4 getModel();
		void setModel(mat4 model);
		pair<float, float> getPosition();
		void move(float x, float y);
		float getRotationAngle();
		void rotate(float angle);
};