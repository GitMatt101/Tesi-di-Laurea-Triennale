#pragma once
#include <glm/vec3.hpp>
#include <glm/vec4.hpp>
using namespace glm;

/**
* Structure of a Vertex.
*
* @param coordinates - position of the vertex.
* @param color - color of the vertex.
*/
struct Vertex {
	vec3 coordinates;
	vec4 color;

	bool operator==(const Vertex& other) const
	{
		return coordinates == other.coordinates && color == other.color;
	}
};