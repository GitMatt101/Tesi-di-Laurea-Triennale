#include "../api/vaoInitializer.hpp"

void initShapeVAO(Shape* shape) {
	// Initialize VAO
	glGenVertexArrays(1, shape->getVAO());
	glBindVertexArray(*shape->getVAO());

	// Initialize vertices' VBO
	glGenBuffers(1, shape->getVerticesVBO());
	glBindBuffer(GL_ARRAY_BUFFER, *shape->getVerticesVBO());
	glBufferData(
		GL_ARRAY_BUFFER,
		shape->getVertices().size() * sizeof(vec3),
		NULL,
		GL_DYNAMIC_DRAW
	);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(0);

	// Initialize vertices' colors' VBO
	glGenBuffers(1, shape->getColorsVBO());
	glBindBuffer(GL_ARRAY_BUFFER, *shape->getColorsVBO());
	glBufferData(
		GL_ARRAY_BUFFER,
		shape->getVertices().size() * sizeof(vec4),
		NULL,
		GL_DYNAMIC_DRAW
	);
	glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(1);
}