#pragma once
#include "../../geometry/api/shape.hpp"

/**
* Initializes a shape's Vertex Array Object and Vertex Buffer Objects.
*
* @param shape - shape to create VAO and VBOs for.
*/
void initShapeVAO(Shape* shape);